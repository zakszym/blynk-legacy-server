package cc.blynk.server.core.model.widgets.ui.reporting;

public enum ReportResult {

    NO_DATA, ERROR, OK, EXPIRED

}
