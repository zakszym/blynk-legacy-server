package cc.blynk.server.core.model.enums;

/**
 * The Blynk Project.
 * Created by Dmitriy Dumanskiy.
 * Created on 20.03.17.
 */
public enum Theme {

    blynk,
    Blynk,
    BlynkLight,
    SparkFun,
    AppTheme, //should be removed in future
    CustomTheme, //should be removed in future
    AppExport //should be removed in future

}
