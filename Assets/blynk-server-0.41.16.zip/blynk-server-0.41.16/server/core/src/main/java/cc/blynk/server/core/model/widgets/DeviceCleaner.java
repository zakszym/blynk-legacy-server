package cc.blynk.server.core.model.widgets;

public interface DeviceCleaner {

    void deleteDevice(int deviceId);

}
