package cc.blynk.server.core.model.widgets.controls;

/**
 * The Blynk Project.
 * Created by Dmitriy Dumanskiy.
 * Created on 01.04.15.
 */
public class VerticalStep extends Step {

}
