package cc.blynk.server.core.model.widgets.ui.reporting;

public enum ReportOutput {

    EXCEL_TAB_PER_DEVICE,
    CSV_FILE_PER_DEVICE_PER_PIN,
    CSV_FILE_PER_DEVICE,
    MERGED_CSV

}
