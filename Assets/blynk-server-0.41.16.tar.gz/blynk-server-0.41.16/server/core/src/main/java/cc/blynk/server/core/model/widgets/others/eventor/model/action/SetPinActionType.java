package cc.blynk.server.core.model.widgets.others.eventor.model.action;

/**
 * The Blynk Project.
 * Created by Dmitriy Dumanskiy.
 * Created on 12.02.17.
 */
public enum SetPinActionType {

    ON, OFF, CUSTOM

}
