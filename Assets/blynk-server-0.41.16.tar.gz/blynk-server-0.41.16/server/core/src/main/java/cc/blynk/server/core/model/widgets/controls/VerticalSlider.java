package cc.blynk.server.core.model.widgets.controls;

/**
 * The Blynk Project.
 * Created by Dmitriy Dumanskiy.
 * Created on 21.03.15.
 */
public class VerticalSlider extends Slider {

}
