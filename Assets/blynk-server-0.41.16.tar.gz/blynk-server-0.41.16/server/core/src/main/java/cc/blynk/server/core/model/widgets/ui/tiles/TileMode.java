package cc.blynk.server.core.model.widgets.ui.tiles;

/**
 * The Blynk Project.
 * Created by Dmitriy Dumanskiy.
 * Created on 02.10.17.
 */
public enum TileMode {

    PAGE, BUTTON, ICON, DIMMER

}
