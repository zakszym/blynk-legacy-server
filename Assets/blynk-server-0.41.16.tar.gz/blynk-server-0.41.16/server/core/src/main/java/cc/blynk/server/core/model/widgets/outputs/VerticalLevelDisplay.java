package cc.blynk.server.core.model.widgets.outputs;

/**
 * The Blynk Project.
 * Created by Dmitriy Dumanskiy.
 * Created on 21.03.15.
 */
public class VerticalLevelDisplay extends LevelDisplay {

}
